package com.example.instagramdmonly

import android.accessibilityservice.AccessibilityService
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

/** Best-effort UI guard. Instagram UI and accessibility metadata may change. */
class DmGuardService : AccessibilityService() {
    private var lastCheck = 0L
    private var lastRedirect = 0L
    private var redirectCount = 0
    private var redirectWindow = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null || !GuardPrefs.enabled(this)) return
        if (event.packageName?.toString() != "com.instagram.android") return
        val now = SystemClock.elapsedRealtime()
        if (now - lastCheck < 450 || now - lastRedirect < 1800) return
        lastCheck = now
        val root = rootInActiveWindow ?: return
        val nodes = mutableListOf<AccessibilityNodeInfo>()
        try {
            walk(root, nodes, 0)
            val selectedLabels = nodes.filter { it.isSelected || it.isChecked }
                .flatMap { labels(it) }.map { it.lowercase() }
            val allLabels = nodes.flatMap { labels(it) }.map { it.lowercase() }
            val inbox = listOf("chats", "direct", "inbox", "채팅", "받은 메시지", "메시지 요청")
            val blocked = listOf("reels", "릴스", "explore", "탐색", "home", "홈", "feed", "피드")
            val selectedBlocked = selectedLabels.any { s -> blocked.any { s.contains(it) } }
            val selectedInbox = selectedLabels.any { s -> inbox.any { s.contains(it) } }
            // Don't treat a mere DM icon in the navigation bar as proof that we're in DM.
            // The guard prefers false negatives rather than interrupting conversations.
            val hasConversationInput = nodes.any { it.isEditable && (it.isFocused || it.isVisibleToUser) }
            val obviousInbox = allLabels.any { s -> listOf("your messages", "message requests", "내 메시지", "메시지 요청").any { s.contains(it) } }
            if (selectedBlocked && !selectedInbox && !hasConversationInput && !obviousInbox) {
                // Prevent endless redirect loops when Instagram ignores its unofficial deep link.
                if (now - redirectWindow > 30000) { redirectWindow = now; redirectCount = 0 }
                if (redirectCount >= 3) return
                redirectCount++
                lastRedirect = now
                InstagramLauncher.openDm(this)
            }
        } finally {
            // Nodes returned by the framework are managed by Android; do not recycle on recent APIs.
        }
    }

    private fun labels(n: AccessibilityNodeInfo): List<String> =
        listOfNotNull(n.text?.toString(), n.contentDescription?.toString(), n.viewIdResourceName)

    private fun walk(n: AccessibilityNodeInfo, out: MutableList<AccessibilityNodeInfo>, depth: Int) {
        if (depth > 18 || out.size >= 350) return
        out.add(n)
        for (i in 0 until n.childCount) n.getChild(i)?.let { walk(it, out, depth + 1) }
    }

    override fun onInterrupt() = Unit
}
