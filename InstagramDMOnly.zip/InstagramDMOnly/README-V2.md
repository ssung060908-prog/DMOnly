# Version 2 (experimental)
The accessibility guard now inspects selected navigation elements rather than searching the entire screen for any occurrence of a DM label. It also limits redirects to prevent loops. This is best-effort and may fail if Instagram does not expose selected navigation state, or if the unofficial DM deep link is ignored. It does not guarantee blocking of feed, reels or stories.

To use on GitHub: delete the old InstagramDMOnly.zip from the repository and upload this ZIP with the same filename, then run the existing GitHub Actions workflow. Verify the latest commit is used. Install the newly built app-debug.apk as an update.
