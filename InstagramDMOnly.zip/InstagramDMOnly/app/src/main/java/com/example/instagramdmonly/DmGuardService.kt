package com.example.instagramdmonly

import android.accessibilityservice.AccessibilityService
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import android.os.SystemClock

class DmGuardService : AccessibilityService() {
    private var lastRedirect = 0L
    private var lastCheck = 0L
    private val dmMarkers = listOf("messages", "chats", "direct", "메시지", "채팅", "쪽지", "inbox")
    private val blockedMarkers = listOf("reels", "릴스", "explore", "탐색", "search", "검색", "feed", "피드")

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (!GuardPrefs.enabled(this) || event == null) return
        if (event.packageName?.toString() != "com.instagram.android") return
        val now = SystemClock.elapsedRealtime()
        if (now - lastCheck < 800 || now - lastRedirect < 3500) return
        lastCheck = now
        val root = rootInActiveWindow ?: return
        val terms = mutableListOf<String>()
        collect(root, terms, 0)
        // Conservative heuristic: avoid redirecting when a DM-specific marker exists.
        // Navigation labels alone are not enough to determine the current screen.
        val screen = terms.joinToString(" ").lowercase()
        val dmPresent = dmMarkers.any { screen.contains(it) }
        val blockedPresent = blockedMarkers.any { screen.contains(it) }
        val activeClass = event.className?.toString()?.lowercase().orEmpty()
        // Only act when a blocked marker is present and no DM marker is visible.
        // This deliberately favors false negatives over breaking conversations.
        if (blockedPresent && !dmPresent && !activeClass.contains("dialog")) {
            lastRedirect = now
            InstagramLauncher.openDm(this)
        }
    }

    private fun collect(node: AccessibilityNodeInfo, out: MutableList<String>, depth: Int) {
        if (depth > 12 || out.size >= 150) return
        node.text?.toString()?.takeIf { it.length <= 80 }?.let(out::add)
        node.contentDescription?.toString()?.takeIf { it.length <= 80 }?.let(out::add)
        for (i in 0 until node.childCount) {
            val child = node.getChild(i) ?: continue
            collect(child, out, depth + 1)
            child.recycle()
        }
    }
    override fun onInterrupt() = Unit
}
