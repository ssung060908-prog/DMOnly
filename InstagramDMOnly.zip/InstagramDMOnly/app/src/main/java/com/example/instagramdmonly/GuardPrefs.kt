package com.example.instagramdmonly

import android.content.Context

object GuardPrefs {
    private const val PREF = "dm_guard"
    private const val ENABLED = "enabled"
    fun enabled(context: Context): Boolean = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).getBoolean(ENABLED, false)
    fun setEnabled(context: Context, enabled: Boolean) = context.getSharedPreferences(PREF, Context.MODE_PRIVATE).edit().putBoolean(ENABLED, enabled).apply()
}
