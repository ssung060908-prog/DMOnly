package com.example.instagramdmonly

import android.accessibilityservice.AccessibilityServiceInfo
import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.view.accessibility.AccessibilityManager

class MainActivity : Activity() {
    private lateinit var status: TextView
    private fun serviceOn(): Boolean {
        val manager = getSystemService(ACCESSIBILITY_SERVICE) as AccessibilityManager
        return manager.getEnabledAccessibilityServiceList(AccessibilityServiceInfo.FEEDBACK_ALL_MASK)
            .any { it.resolveInfo.serviceInfo.packageName == packageName &&
                it.resolveInfo.serviceInfo.name == DmGuardService::class.java.name }
    }
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(40, 64, 40, 32)
        }
        fun addButton(text: String, action: () -> Unit) {
            layout.addView(Button(this).apply {
                this.text = text
                setOnClickListener { action() }
            }, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        }
        layout.addView(TextView(this).apply { text = "Instagram DM Only"; textSize = 26f })
        status = TextView(this).apply { textSize = 16f; setPadding(0, 24, 0, 24) }
        layout.addView(status)
        addButton("1. 접근성 서비스 설정") {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        }
        addButton("2. DM 전용 모드 켜고 인스타그램 열기") {
            if (!serviceOn()) {
                status.text = "먼저 설정에서 Instagram DM Only 접근성 서비스를 켜세요."
            } else {
                GuardPrefs.setEnabled(this, true)
                refresh()
                InstagramLauncher.openDm(this)
            }
        }
        addButton("DM 화면 열기") { InstagramLauncher.openDm(this) }
        addButton("DM 전용 모드 끄기") {
            GuardPrefs.setEnabled(this, false)
            refresh()
        }
        layout.addView(TextView(this).apply {
            text = "주의: 화면 텍스트 기반의 실험적 차단 기능입니다. 인스타그램 업데이트나 언어 설정에 따라 우회되거나 잘못 차단될 수 있습니다."
            setPadding(0, 28, 0, 0)
        })
        setContentView(layout)
    }
    override fun onResume() { super.onResume(); refresh() }
    private fun refresh() {
        status.text = "접근성 서비스: ${if (serviceOn()) "켜짐" else "꺼짐"}\nDM 전용 모드: ${if (GuardPrefs.enabled(this)) "켜짐" else "꺼짐"}"
    }
}
