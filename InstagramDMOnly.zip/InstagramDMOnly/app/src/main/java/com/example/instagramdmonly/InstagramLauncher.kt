package com.example.instagramdmonly

import android.content.Context
import android.content.Intent
import android.net.Uri

object InstagramLauncher {
    fun openDm(context: Context) {
        // Instagram may change or reject this undocumented URI in future versions.
        val deepLink = Intent(Intent.ACTION_VIEW, Uri.parse("instagram://direct-inbox"))
            .setPackage("com.instagram.android")
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        try {
            if (deepLink.resolveActivity(context.packageManager) != null) {
                context.startActivity(deepLink)
                return
            }
        } catch (_: Exception) { }
        // Fallback: open the Instagram app; the user may need to tap Messages.
        val launch = context.packageManager.getLaunchIntentForPackage("com.instagram.android")
        if (launch != null) context.startActivity(launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
        else context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.instagram.com/direct/inbox/"))
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
