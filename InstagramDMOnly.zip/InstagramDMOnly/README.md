# Instagram DM Only (experimental Android app)

## Build
1. Android Studio (JDK 17)에서 이 폴더를 Open 합니다.
2. Gradle sync가 완료되면 Android SDK 35를 설치합니다(필요시 안내 표시).
3. 실제 Android 기기를 USB 디버깅으로 연결하고 Run을 누릅니다.
4. 앱에서 '접근성 서비스 설정'을 눌러 Instagram DM Only 서비스를 활성화합니다.
5. 앱으로 돌아와 'DM 전용 모드 켜고 인스타그램 열기'를 누릅니다.
6. 중지하려면 앱의 'DM 전용 모드 끄기'를 누릅니다.

## Important limitations
- This is a proof of concept, not a reliable Instagram UI lockdown. Instagram may change its UI, accessibility labels, or private deep links at any time.
- The heuristic scans accessibility text and may fail to detect a blocked screen, or redirect on unrelated content. It is intentionally conservative.
- `instagram://direct-inbox` is undocumented and may not open the inbox. The fallback launches Instagram normally.
- Accessibility services can inspect sensitive on-screen text. This app does not store, upload, or log screen text, and requests no Internet permission.
- This project was not compiled or device-tested in this environment. Validate on your own device and adjust the heuristics for the installed Instagram version/language.
- Accessibility API use for Play Store distribution is subject to Google Play policies and disclosure requirements.

## Structure
- MainActivity.kt: enable/disable guard and open Instagram
- DmGuardService.kt: heuristic detection and redirect
- InstagramLauncher.kt: best-effort DM deep link
- GuardPrefs.kt: persistent local setting
